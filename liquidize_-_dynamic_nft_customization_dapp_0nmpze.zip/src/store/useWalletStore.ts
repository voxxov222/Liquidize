import { create } from 'zustand';

interface WalletState {
  address: string | null;
  chainId: number | null;
  isConnected: boolean;
  balance: string;
  connect: () => Promise<void>;
  disconnect: () => void;
  switchChain: (chainId: number) => Promise<void>;
}

export const useWalletStore = create<WalletState>((set) => ({
  address: null,
  chainId: null,
  isConnected: false,
  balance: '0',
  
  connect: async () => {
    try {
      // Mock wallet connection
      const mockAddress = '0x' + Math.random().toString(16).substring(2, 42);
      const mockChainId = 1;
      const mockBalance = (Math.random() * 10).toFixed(4);
      
      set({
        address: mockAddress,
        chainId: mockChainId,
        isConnected: true,
        balance: mockBalance,
      });
    } catch (error) {
      console.error('Failed to connect wallet:', error);
    }
  },
  
  disconnect: () => {
    set({
      address: null,
      chainId: null,
      isConnected: false,
      balance: '0',
    });
  },
  
  switchChain: async (chainId: number) => {
    try {
      set({ chainId });
    } catch (error) {
      console.error('Failed to switch chain:', error);
    }
  },
}));
