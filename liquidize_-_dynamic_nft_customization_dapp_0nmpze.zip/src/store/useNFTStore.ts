import { create } from 'zustand';

export interface NFTAbility {
  name: string;
  level: number;
  description: string;
}

export interface NFT {
  id: string;
  name: string;
  image: string;
  personality: string;
  abilities: NFTAbility[];
  liquidityValue: number;
  liquidityToken: string;
  chainId: number;
  owner: string;
  isDynamic: boolean;
  lastUpdate: number;
}

interface NFTState {
  nfts: NFT[];
  selectedNFT: NFT | null;
  isCreating: boolean;
  isMinting: boolean;
  addNFT: (nft: NFT) => void;
  updateNFT: (id: string, updates: Partial<NFT>) => void;
  selectNFT: (nft: NFT | null) => void;
  setCreating: (isCreating: boolean) => void;
  setMinting: (isMinting: boolean) => void;
}

export const useNFTStore = create<NFTState>((set) => ({
  nfts: [],
  selectedNFT: null,
  isCreating: false,
  isMinting: false,
  
  addNFT: (nft) => set((state) => ({ nfts: [...state.nfts, nft] })),
  
  updateNFT: (id, updates) => set((state) => ({
    nfts: state.nfts.map((nft) => nft.id === id ? { ...nft, ...updates } : nft),
    selectedNFT: state.selectedNFT?.id === id 
      ? { ...state.selectedNFT, ...updates } 
      : state.selectedNFT,
  })),
  
  selectNFT: (nft) => set({ selectedNFT: nft }),
  setCreating: (isCreating) => set({ isCreating }),
  setMinting: (isMinting) => set({ isMinting }),
}));
