import { motion } from 'framer-motion';
import { Sparkles, Zap, Globe, Coins } from 'lucide-react';

export default function Hero() {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden pt-20">
      {/* Animated Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-[#0F172A] via-[#1E293B] to-[#0F172A]">
        <div className="absolute inset-0 opacity-30">
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-[#9E7FFF] rounded-full blur-[120px] animate-pulse"></div>
          <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-[#38bdf8] rounded-full blur-[120px] animate-pulse delay-1000"></div>
        </div>
        
        {/* Floating Particles */}
        {[...Array(20)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-2 h-2 bg-[#9E7FFF] rounded-full"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
            }}
            animate={{
              y: [0, -30, 0],
              opacity: [0.2, 0.8, 0.2],
            }}
            transition={{
              duration: 3 + Math.random() * 2,
              repeat: Infinity,
              delay: Math.random() * 2,
            }}
          />
        ))}
      </div>

      {/* Content */}
      <div className="relative z-10 max-w-6xl mx-auto px-6 text-center">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-[#262626]/50 backdrop-blur-sm rounded-full border border-[#2F2F2F] mb-6">
            <Sparkles className="w-4 h-4 text-[#9E7FFF]" />
            <span className="text-sm text-[#A3A3A3]">Next-Gen Dynamic NFTs</span>
          </div>

          <h1 className="text-6xl md:text-8xl font-bold mb-6 leading-tight">
            <span className="bg-gradient-to-r from-[#9E7FFF] via-[#38bdf8] to-[#f472b6] bg-clip-text text-transparent">
              Liquidize
            </span>
            <br />
            <span className="text-[#FFFFFF]">Your NFTs</span>
          </h1>

          <p className="text-xl md:text-2xl text-[#A3A3A3] mb-12 max-w-3xl mx-auto leading-relaxed">
            Create dynamic NFTs with embedded AI agents, instant liquidity, and cross-chain capabilities. 
            Customize personalities, abilities, and mint crypto directly into your NFTs.
          </p>

          <div className="flex flex-wrap items-center justify-center gap-4 mb-16">
            <motion.button
              className="px-8 py-4 bg-gradient-to-r from-[#9E7FFF] to-[#38bdf8] rounded-lg font-semibold text-[#FFFFFF] text-lg hover:scale-105 transition-transform shadow-2xl shadow-[#9E7FFF]/30"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              Start Creating
            </motion.button>
            
            <motion.button
              className="px-8 py-4 bg-[#262626] rounded-lg font-semibold text-[#FFFFFF] text-lg border border-[#2F2F2F] hover:border-[#9E7FFF] transition-all"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              Explore Marketplace
            </motion.button>
          </div>

          {/* Feature Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 max-w-5xl mx-auto">
            {[
              { icon: Sparkles, title: 'AI Agents', desc: 'Customizable personalities' },
              { icon: Zap, title: 'Dynamic NFTs', desc: 'Evolving abilities' },
              { icon: Globe, title: 'Cross-Chain', desc: 'Multi-chain support' },
              { icon: Coins, title: 'Instant Liquidity', desc: 'Embedded value' },
            ].map((feature, i) => (
              <motion.div
                key={i}
                className="p-6 bg-[#262626]/50 backdrop-blur-sm rounded-2xl border border-[#2F2F2F] hover:border-[#9E7FFF] transition-all group"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 + i * 0.1 }}
                whileHover={{ y: -5 }}
              >
                <feature.icon className="w-8 h-8 text-[#9E7FFF] mb-4 group-hover:scale-110 transition-transform" />
                <h3 className="text-lg font-bold text-[#FFFFFF] mb-2">{feature.title}</h3>
                <p className="text-sm text-[#A3A3A3]">{feature.desc}</p>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>

      {/* Scroll Indicator */}
      <motion.div
        className="absolute bottom-8 left-1/2 transform -translate-x-1/2"
        animate={{ y: [0, 10, 0] }}
        transition={{ duration: 2, repeat: Infinity }}
      >
        <div className="w-6 h-10 border-2 border-[#9E7FFF] rounded-full flex items-start justify-center p-2">
          <div className="w-1 h-2 bg-[#9E7FFF] rounded-full"></div>
        </div>
      </motion.div>
    </section>
  );
}
