import { motion } from 'framer-motion';
import { useNFTStore } from '../store/useNFTStore';
import { Sparkles, TrendingUp, Zap, ExternalLink } from 'lucide-react';

export default function Portfolio() {
  const { nfts, selectNFT } = useNFTStore();

  if (nfts.length === 0) {
    return (
      <section id="portfolio" className="py-24 px-6 bg-[#0F172A]">
        <div className="max-w-7xl mx-auto text-center">
          <h2 className="text-5xl font-bold text-[#FFFFFF] mb-4">Your Portfolio</h2>
          <p className="text-xl text-[#A3A3A3] mb-12">Create your first NFT to get started</p>
          
          <div className="max-w-md mx-auto p-12 bg-[#262626]/50 backdrop-blur-sm rounded-2xl border border-[#2F2F2F]">
            <Sparkles className="w-16 h-16 text-[#9E7FFF] mx-auto mb-4" />
            <p className="text-lg text-[#A3A3A3]">No NFTs yet. Start creating!</p>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section id="portfolio" className="py-24 px-6 bg-[#0F172A]">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="text-5xl font-bold text-[#FFFFFF] mb-4">
            Your <span className="bg-gradient-to-r from-[#9E7FFF] to-[#38bdf8] bg-clip-text text-transparent">Portfolio</span>
          </h2>
          <p className="text-xl text-[#A3A3A3]">Manage and track your dynamic NFTs</p>
        </motion.div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          <div className="p-6 bg-[#262626]/50 backdrop-blur-sm rounded-2xl border border-[#2F2F2F]">
            <p className="text-sm text-[#A3A3A3] mb-2">Total NFTs</p>
            <p className="text-3xl font-bold text-[#FFFFFF]">{nfts.length}</p>
          </div>
          
          <div className="p-6 bg-[#262626]/50 backdrop-blur-sm rounded-2xl border border-[#2F2F2F]">
            <p className="text-sm text-[#A3A3A3] mb-2">Total Liquidity</p>
            <p className="text-3xl font-bold text-[#FFFFFF]">
              {nfts.reduce((sum, nft) => sum + nft.liquidityValue, 0).toFixed(2)} ETH
            </p>
          </div>
          
          <div className="p-6 bg-[#262626]/50 backdrop-blur-sm rounded-2xl border border-[#2F2F2F]">
            <p className="text-sm text-[#A3A3A3] mb-2">Active Abilities</p>
            <p className="text-3xl font-bold text-[#FFFFFF]">
              {nfts.reduce((sum, nft) => sum + nft.abilities.length, 0)}
            </p>
          </div>
        </div>

        {/* NFT Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {nfts.map((nft, index) => (
            <motion.div
              key={nft.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="group bg-[#262626]/50 backdrop-blur-sm rounded-2xl border border-[#2F2F2F] overflow-hidden hover:border-[#9E7FFF] transition-all cursor-pointer"
              onClick={() => selectNFT(nft)}
              whileHover={{ y: -5 }}
            >
              {/* Image */}
              <div className="relative h-64 overflow-hidden">
                <img 
                  src={nft.image} 
                  alt={nft.name}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0F172A] to-transparent opacity-60"></div>
                
                {/* Dynamic Badge */}
                {nft.isDynamic && (
                  <div className="absolute top-4 right-4 px-3 py-1 bg-[#9E7FFF]/90 backdrop-blur-sm rounded-full flex items-center gap-2">
                    <Zap className="w-4 h-4 text-[#FFFFFF]" />
                    <span className="text-xs font-medium text-[#FFFFFF]">Dynamic</span>
                  </div>
                )}
              </div>

              {/* Content */}
              <div className="p-6">
                <h3 className="text-xl font-bold text-[#FFFFFF] mb-2">{nft.name}</h3>
                
                <div className="flex items-center gap-2 mb-4">
                  <Sparkles className="w-4 h-4 text-[#9E7FFF]" />
                  <span className="text-sm text-[#A3A3A3]">{nft.personality}</span>
                </div>

                {/* Abilities */}
                <div className="flex flex-wrap gap-2 mb-4">
                  {nft.abilities.slice(0, 3).map((ability) => (
                    <span
                      key={ability.name}
                      className="px-3 py-1 bg-[#171717] rounded-full text-xs text-[#FFFFFF] border border-[#2F2F2F]"
                    >
                      {ability.name}
                    </span>
                  ))}
                  {nft.abilities.length > 3 && (
                    <span className="px-3 py-1 bg-[#171717] rounded-full text-xs text-[#A3A3A3] border border-[#2F2F2F]">
                      +{nft.abilities.length - 3}
                    </span>
                  )}
                </div>

                {/* Liquidity */}
                <div className="flex items-center justify-between pt-4 border-t border-[#2F2F2F]">
                  <div className="flex items-center gap-2">
                    <TrendingUp className="w-4 h-4 text-[#10b981]" />
                    <span className="text-sm text-[#A3A3A3]">Floor Value</span>
                  </div>
                  <span className="text-lg font-bold text-[#FFFFFF]">
                    {nft.liquidityValue} {nft.liquidityToken}
                  </span>
                </div>

                {/* View Details */}
                <button className="w-full mt-4 px-4 py-2 bg-gradient-to-r from-[#9E7FFF] to-[#38bdf8] rounded-lg font-medium text-[#FFFFFF] hover:scale-105 transition-transform flex items-center justify-center gap-2">
                  View Details
                  <ExternalLink className="w-4 h-4" />
                </button>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
