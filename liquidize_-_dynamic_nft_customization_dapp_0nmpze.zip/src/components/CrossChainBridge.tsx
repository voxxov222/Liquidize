import { useState } from 'react';
import { motion } from 'framer-motion';
import { ArrowRight, Globe, Loader2, CheckCircle2 } from 'lucide-react';
import { useNFTStore } from '../store/useNFTStore';

const CHAINS = [
  { id: 1, name: 'Ethereum', icon: '⟠', color: '#627EEA' },
  { id: 137, name: 'Polygon', icon: '⬡', color: '#8247E5' },
  { id: 56, name: 'BSC', icon: '◆', color: '#F3BA2F' },
  { id: 43114, name: 'Avalanche', icon: '▲', color: '#E84142' },
  { id: 42161, name: 'Arbitrum', icon: '◉', color: '#28A0F0' },
];

export default function CrossChainBridge() {
  const { nfts } = useNFTStore();
  const [selectedNFT, setSelectedNFT] = useState<string>('');
  const [sourceChain, setSourceChain] = useState(1);
  const [targetChain, setTargetChain] = useState(137);
  const [isBridging, setIsBridging] = useState(false);
  const [bridgeComplete, setBridgeComplete] = useState(false);

  const handleBridge = async () => {
    if (!selectedNFT) return;

    setIsBridging(true);
    setBridgeComplete(false);

    // Simulate bridge process
    await new Promise(resolve => setTimeout(resolve, 3000));

    setIsBridging(false);
    setBridgeComplete(true);

    setTimeout(() => {
      setBridgeComplete(false);
      setSelectedNFT('');
    }, 3000);
  };

  const sourceChainData = CHAINS.find(c => c.id === sourceChain);
  const targetChainData = CHAINS.find(c => c.id === targetChain);

  return (
    <section id="bridge" className="py-24 px-6 bg-gradient-to-b from-[#1E293B] to-[#0F172A]">
      <div className="max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-[#262626]/50 backdrop-blur-sm rounded-full border border-[#2F2F2F] mb-6">
            <Globe className="w-4 h-4 text-[#9E7FFF]" />
            <span className="text-sm text-[#A3A3A3]">Cross-Chain Interoperability</span>
          </div>

          <h2 className="text-5xl font-bold text-[#FFFFFF] mb-4">
            Bridge Your <span className="bg-gradient-to-r from-[#9E7FFF] to-[#38bdf8] bg-clip-text text-transparent">NFTs</span>
          </h2>
          <p className="text-xl text-[#A3A3A3]">Transfer NFTs seamlessly across multiple blockchains</p>
        </motion.div>

        <div className="bg-[#262626]/50 backdrop-blur-sm rounded-2xl border border-[#2F2F2F] p-8">
          {/* Select NFT */}
          <div className="mb-8">
            <label className="block text-sm font-medium text-[#A3A3A3] mb-3">Select NFT to Bridge</label>
            <select
              value={selectedNFT}
              onChange={(e) => setSelectedNFT(e.target.value)}
              className="w-full px-4 py-3 bg-[#171717] border border-[#2F2F2F] rounded-lg text-[#FFFFFF] focus:border-[#9E7FFF] focus:outline-none transition-colors"
            >
              <option value="">Choose an NFT</option>
              {nfts.map((nft) => (
                <option key={nft.id} value={nft.id}>
                  {nft.name} - {nft.liquidityValue} {nft.liquidityToken}
                </option>
              ))}
            </select>
          </div>

          {/* Chain Selection */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            {/* Source Chain */}
            <div>
              <label className="block text-sm font-medium text-[#A3A3A3] mb-3">From</label>
              <div className="space-y-2">
                {CHAINS.map((chain) => (
                  <button
                    key={chain.id}
                    onClick={() => setSourceChain(chain.id)}
                    className={`w-full p-4 rounded-lg border-2 transition-all flex items-center gap-3 ${
                      sourceChain === chain.id
                        ? 'border-[#9E7FFF] bg-[#9E7FFF]/10'
                        : 'border-[#2F2F2F] hover:border-[#9E7FFF]/50'
                    }`}
                  >
                    <span className="text-2xl">{chain.icon}</span>
                    <span className="text-sm font-medium text-[#FFFFFF]">{chain.name}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Arrow */}
            <div className="flex items-center justify-center">
              <motion.div
                animate={{ x: [0, 10, 0] }}
                transition={{ duration: 2, repeat: Infinity }}
                className="w-12 h-12 bg-gradient-to-r from-[#9E7FFF] to-[#38bdf8] rounded-full flex items-center justify-center"
              >
                <ArrowRight className="w-6 h-6 text-[#FFFFFF]" />
              </motion.div>
            </div>

            {/* Target Chain */}
            <div>
              <label className="block text-sm font-medium text-[#A3A3A3] mb-3">To</label>
              <div className="space-y-2">
                {CHAINS.filter(c => c.id !== sourceChain).map((chain) => (
                  <button
                    key={chain.id}
                    onClick={() => setTargetChain(chain.id)}
                    className={`w-full p-4 rounded-lg border-2 transition-all flex items-center gap-3 ${
                      targetChain === chain.id
                        ? 'border-[#9E7FFF] bg-[#9E7FFF]/10'
                        : 'border-[#2F2F2F] hover:border-[#9E7FFF]/50'
                    }`}
                  >
                    <span className="text-2xl">{chain.icon}</span>
                    <span className="text-sm font-medium text-[#FFFFFF]">{chain.name}</span>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Bridge Info */}
          {selectedNFT && (
            <div className="bg-[#171717] rounded-lg p-6 border border-[#2F2F2F] mb-8">
              <h4 className="text-lg font-bold text-[#FFFFFF] mb-4">Bridge Details</h4>
              <div className="space-y-3 text-sm">
                <div className="flex justify-between">
                  <span className="text-[#A3A3A3]">Source Chain:</span>
                  <span className="text-[#FFFFFF] flex items-center gap-2">
                    <span>{sourceChainData?.icon}</span>
                    {sourceChainData?.name}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#A3A3A3]">Target Chain:</span>
                  <span className="text-[#FFFFFF] flex items-center gap-2">
                    <span>{targetChainData?.icon}</span>
                    {targetChainData?.name}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#A3A3A3]">Estimated Time:</span>
                  <span className="text-[#FFFFFF]">~2-5 minutes</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#A3A3A3]">Bridge Fee:</span>
                  <span className="text-[#FFFFFF]">0.001 ETH</span>
                </div>
              </div>
            </div>
          )}

          {/* Bridge Button */}
          <button
            onClick={handleBridge}
            disabled={!selectedNFT || isBridging || bridgeComplete}
            className="w-full px-8 py-4 bg-gradient-to-r from-[#9E7FFF] to-[#38bdf8] rounded-lg font-bold text-[#FFFFFF] hover:scale-105 transition-transform disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:scale-100 flex items-center justify-center gap-3"
          >
            {isBridging ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                Bridging NFT...
              </>
            ) : bridgeComplete ? (
              <>
                <CheckCircle2 className="w-5 h-5" />
                Bridge Complete!
              </>
            ) : (
              <>
                <Globe className="w-5 h-5" />
                Bridge NFT
              </>
            )}
          </button>

          {/* Progress Indicator */}
          {isBridging && (
            <div className="mt-6">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-[#A3A3A3]">Processing...</span>
                <span className="text-sm text-[#9E7FFF]">Step 2 of 3</span>
              </div>
              <div className="w-full h-2 bg-[#171717] rounded-full overflow-hidden">
                <motion.div
                  className="h-full bg-gradient-to-r from-[#9E7FFF] to-[#38bdf8]"
                  initial={{ width: '0%' }}
                  animate={{ width: '66%' }}
                  transition={{ duration: 2 }}
                />
              </div>
            </div>
          )}
        </div>

        {/* Supported Chains */}
        <div className="mt-12 text-center">
          <p className="text-sm text-[#A3A3A3] mb-4">Supported Networks</p>
          <div className="flex items-center justify-center gap-6">
            {CHAINS.map((chain) => (
              <div key={chain.id} className="flex flex-col items-center gap-2">
                <div className="w-12 h-12 rounded-full bg-[#262626] border border-[#2F2F2F] flex items-center justify-center text-2xl">
                  {chain.icon}
                </div>
                <span className="text-xs text-[#A3A3A3]">{chain.name}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
