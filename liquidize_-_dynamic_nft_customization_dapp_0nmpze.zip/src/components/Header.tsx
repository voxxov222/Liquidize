import { Droplets, Wallet, ChevronDown } from 'lucide-react';
import { useWalletStore } from '../store/useWalletStore';
import { motion } from 'framer-motion';

const SUPPORTED_CHAINS = [
  { id: 1, name: 'Ethereum', icon: '⟠' },
  { id: 137, name: 'Polygon', icon: '⬡' },
  { id: 56, name: 'BSC', icon: '◆' },
  { id: 43114, name: 'Avalanche', icon: '▲' },
  { id: 42161, name: 'Arbitrum', icon: '◉' },
];

export default function Header() {
  const { address, chainId, isConnected, balance, connect, disconnect, switchChain } = useWalletStore();

  const currentChain = SUPPORTED_CHAINS.find(c => c.id === chainId) || SUPPORTED_CHAINS[0];

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-[#0F172A]/80 backdrop-blur-xl border-b border-[#2F2F2F]">
      <div className="max-w-7xl mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <motion.div 
            className="flex items-center gap-3"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
          >
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-r from-[#9E7FFF] to-[#38bdf8] blur-xl opacity-50"></div>
              <Droplets className="w-8 h-8 text-[#9E7FFF] relative" />
            </div>
            <div>
              <h1 className="text-2xl font-bold bg-gradient-to-r from-[#9E7FFF] to-[#38bdf8] bg-clip-text text-transparent">
                Liquidize
              </h1>
              <p className="text-xs text-[#A3A3A3]">Dynamic NFT Platform</p>
            </div>
          </motion.div>

          {/* Navigation */}
          <nav className="hidden md:flex items-center gap-8">
            <a href="#create" className="text-[#FFFFFF] hover:text-[#9E7FFF] transition-colors">Create</a>
            <a href="#marketplace" className="text-[#FFFFFF] hover:text-[#9E7FFF] transition-colors">Marketplace</a>
            <a href="#bridge" className="text-[#FFFFFF] hover:text-[#9E7FFF] transition-colors">Bridge</a>
            <a href="#portfolio" className="text-[#FFFFFF] hover:text-[#9E7FFF] transition-colors">Portfolio</a>
          </nav>

          {/* Wallet Section */}
          <div className="flex items-center gap-3">
            {isConnected && (
              <>
                {/* Chain Selector */}
                <div className="relative group">
                  <button className="flex items-center gap-2 px-4 py-2 bg-[#262626] rounded-lg border border-[#2F2F2F] hover:border-[#9E7FFF] transition-all">
                    <span className="text-xl">{currentChain.icon}</span>
                    <span className="text-sm text-[#FFFFFF]">{currentChain.name}</span>
                    <ChevronDown className="w-4 h-4 text-[#A3A3A3]" />
                  </button>
                  
                  <div className="absolute top-full right-0 mt-2 w-48 bg-[#262626] rounded-lg border border-[#2F2F2F] opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all">
                    {SUPPORTED_CHAINS.map((chain) => (
                      <button
                        key={chain.id}
                        onClick={() => switchChain(chain.id)}
                        className="w-full flex items-center gap-3 px-4 py-3 hover:bg-[#2F2F2F] transition-colors first:rounded-t-lg last:rounded-b-lg"
                      >
                        <span className="text-xl">{chain.icon}</span>
                        <span className="text-sm text-[#FFFFFF]">{chain.name}</span>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Balance */}
                <div className="px-4 py-2 bg-[#262626] rounded-lg border border-[#2F2F2F]">
                  <p className="text-sm text-[#A3A3A3]">Balance</p>
                  <p className="text-lg font-bold text-[#FFFFFF]">{balance} ETH</p>
                </div>
              </>
            )}

            {/* Connect Button */}
            <motion.button
              onClick={isConnected ? disconnect : connect}
              className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-[#9E7FFF] to-[#38bdf8] rounded-lg font-semibold text-[#FFFFFF] hover:scale-105 transition-transform shadow-lg shadow-[#9E7FFF]/20"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <Wallet className="w-5 h-5" />
              {isConnected ? `${address?.slice(0, 6)}...${address?.slice(-4)}` : 'Connect Wallet'}
            </motion.button>
          </div>
        </div>
      </div>
    </header>
  );
}
