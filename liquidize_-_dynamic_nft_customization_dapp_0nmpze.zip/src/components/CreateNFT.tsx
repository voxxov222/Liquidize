import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Upload, Sparkles, Brain, Code, Gamepad2, Search, Plus, X, Coins } from 'lucide-react';
import { useNFTStore } from '../store/useNFTStore';
import { useWalletStore } from '../store/useWalletStore';

const PERSONALITIES = [
  'Analytical', 'Creative', 'Strategic', 'Empathetic', 'Adventurous', 'Methodical'
];

const ABILITIES = [
  { name: 'Research', icon: Search, color: '#38bdf8' },
  { name: 'Coding', icon: Code, color: '#10b981' },
  { name: 'Game Development', icon: Gamepad2, color: '#f472b6' },
  { name: 'Data Analysis', icon: Brain, color: '#9E7FFF' },
];

export default function CreateNFT() {
  const [step, setStep] = useState(1);
  const [nftData, setNftData] = useState({
    name: '',
    image: '',
    personality: '',
    abilities: [] as string[],
    liquidityAmount: '',
    liquidityToken: 'ETH',
  });

  const { addNFT, setMinting } = useNFTStore();
  const { isConnected, address, chainId } = useWalletStore();

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      // Mock image URL from Unsplash for blockchain/crypto theme
      const mockImages = [
        'https://images.unsplash.com/photo-1639762681485-074b7f938ba0?w=800',
        'https://images.unsplash.com/photo-1644361566696-3d442b5b482a?w=800',
        'https://images.unsplash.com/photo-1642104704074-907c0698cbd9?w=800',
      ];
      setNftData({ ...nftData, image: mockImages[Math.floor(Math.random() * mockImages.length)] });
    }
  };

  const toggleAbility = (ability: string) => {
    setNftData({
      ...nftData,
      abilities: nftData.abilities.includes(ability)
        ? nftData.abilities.filter(a => a !== ability)
        : [...nftData.abilities, ability],
    });
  };

  const handleMint = async () => {
    if (!isConnected) {
      alert('Please connect your wallet first');
      return;
    }

    setMinting(true);
    
    // Simulate minting process
    await new Promise(resolve => setTimeout(resolve, 2000));

    const newNFT = {
      id: `nft-${Date.now()}`,
      name: nftData.name,
      image: nftData.image,
      personality: nftData.personality,
      abilities: nftData.abilities.map(name => ({
        name,
        level: 1,
        description: `${name} capability`,
      })),
      liquidityValue: parseFloat(nftData.liquidityAmount) || 0,
      liquidityToken: nftData.liquidityToken,
      chainId: chainId || 1,
      owner: address || '',
      isDynamic: true,
      lastUpdate: Date.now(),
    };

    addNFT(newNFT);
    setMinting(false);
    
    // Reset form
    setNftData({
      name: '',
      image: '',
      personality: '',
      abilities: [],
      liquidityAmount: '',
      liquidityToken: 'ETH',
    });
    setStep(1);
  };

  return (
    <section id="create" className="py-24 px-6 bg-gradient-to-b from-[#0F172A] to-[#1E293B]">
      <div className="max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="text-5xl font-bold text-[#FFFFFF] mb-4">
            Create Your <span className="bg-gradient-to-r from-[#9E7FFF] to-[#38bdf8] bg-clip-text text-transparent">Dynamic NFT</span>
          </h2>
          <p className="text-xl text-[#A3A3A3]">Customize every aspect of your AI-powered NFT</p>
        </motion.div>

        {/* Progress Steps */}
        <div className="flex items-center justify-center gap-4 mb-12">
          {[1, 2, 3, 4].map((s) => (
            <div key={s} className="flex items-center">
              <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold transition-all ${
                step >= s 
                  ? 'bg-gradient-to-r from-[#9E7FFF] to-[#38bdf8] text-[#FFFFFF]' 
                  : 'bg-[#262626] text-[#A3A3A3]'
              }`}>
                {s}
              </div>
              {s < 4 && <div className={`w-16 h-1 ${step > s ? 'bg-[#9E7FFF]' : 'bg-[#262626]'}`} />}
            </div>
          ))}
        </div>

        {/* Step Content */}
        <AnimatePresence mode="wait">
          <motion.div
            key={step}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="bg-[#262626]/50 backdrop-blur-sm rounded-2xl border border-[#2F2F2F] p-8"
          >
            {step === 1 && (
              <div className="space-y-6">
                <h3 className="text-2xl font-bold text-[#FFFFFF] mb-6">Basic Information</h3>
                
                <div>
                  <label className="block text-sm font-medium text-[#A3A3A3] mb-2">NFT Name</label>
                  <input
                    type="text"
                    value={nftData.name}
                    onChange={(e) => setNftData({ ...nftData, name: e.target.value })}
                    className="w-full px-4 py-3 bg-[#171717] border border-[#2F2F2F] rounded-lg text-[#FFFFFF] focus:border-[#9E7FFF] focus:outline-none transition-colors"
                    placeholder="Enter NFT name"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-[#A3A3A3] mb-2">Upload Image</label>
                  <div className="relative">
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleImageUpload}
                      className="hidden"
                      id="image-upload"
                    />
                    <label
                      htmlFor="image-upload"
                      className="flex flex-col items-center justify-center w-full h-48 border-2 border-dashed border-[#2F2F2F] rounded-lg cursor-pointer hover:border-[#9E7FFF] transition-colors"
                    >
                      {nftData.image ? (
                        <img src={nftData.image} alt="Preview" className="w-full h-full object-cover rounded-lg" />
                      ) : (
                        <>
                          <Upload className="w-12 h-12 text-[#A3A3A3] mb-2" />
                          <p className="text-sm text-[#A3A3A3]">Click to upload image</p>
                        </>
                      )}
                    </label>
                  </div>
                </div>
              </div>
            )}

            {step === 2 && (
              <div className="space-y-6">
                <h3 className="text-2xl font-bold text-[#FFFFFF] mb-6">AI Personality</h3>
                
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  {PERSONALITIES.map((personality) => (
                    <button
                      key={personality}
                      onClick={() => setNftData({ ...nftData, personality })}
                      className={`p-4 rounded-lg border-2 transition-all ${
                        nftData.personality === personality
                          ? 'border-[#9E7FFF] bg-[#9E7FFF]/10'
                          : 'border-[#2F2F2F] hover:border-[#9E7FFF]/50'
                      }`}
                    >
                      <Brain className="w-6 h-6 text-[#9E7FFF] mb-2" />
                      <p className="text-sm font-medium text-[#FFFFFF]">{personality}</p>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {step === 3 && (
              <div className="space-y-6">
                <h3 className="text-2xl font-bold text-[#FFFFFF] mb-6">Select Abilities</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {ABILITIES.map((ability) => (
                    <button
                      key={ability.name}
                      onClick={() => toggleAbility(ability.name)}
                      className={`p-6 rounded-lg border-2 transition-all ${
                        nftData.abilities.includes(ability.name)
                          ? 'border-[#9E7FFF] bg-[#9E7FFF]/10'
                          : 'border-[#2F2F2F] hover:border-[#9E7FFF]/50'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-3">
                        <ability.icon className="w-8 h-8" style={{ color: ability.color }} />
                        {nftData.abilities.includes(ability.name) && (
                          <div className="w-6 h-6 bg-[#9E7FFF] rounded-full flex items-center justify-center">
                            <Plus className="w-4 h-4 text-[#FFFFFF] rotate-45" />
                          </div>
                        )}
                      </div>
                      <p className="text-lg font-medium text-[#FFFFFF]">{ability.name}</p>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {step === 4 && (
              <div className="space-y-6">
                <h3 className="text-2xl font-bold text-[#FFFFFF] mb-6">Add Liquidity</h3>
                
                <div className="bg-[#171717] rounded-lg p-6 border border-[#2F2F2F]">
                  <div className="flex items-center gap-3 mb-4">
                    <Coins className="w-6 h-6 text-[#9E7FFF]" />
                    <p className="text-lg font-medium text-[#FFFFFF]">Embed Instant Floor Value</p>
                  </div>
                  <p className="text-sm text-[#A3A3A3] mb-6">
                    Add cryptocurrency directly into your NFT to give it instant liquidity and floor value
                  </p>

                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-[#A3A3A3] mb-2">Amount</label>
                      <input
                        type="number"
                        step="0.01"
                        value={nftData.liquidityAmount}
                        onChange={(e) => setNftData({ ...nftData, liquidityAmount: e.target.value })}
                        className="w-full px-4 py-3 bg-[#0F172A] border border-[#2F2F2F] rounded-lg text-[#FFFFFF] focus:border-[#9E7FFF] focus:outline-none transition-colors"
                        placeholder="0.00"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-[#A3A3A3] mb-2">Token</label>
                      <select
                        value={nftData.liquidityToken}
                        onChange={(e) => setNftData({ ...nftData, liquidityToken: e.target.value })}
                        className="w-full px-4 py-3 bg-[#0F172A] border border-[#2F2F2F] rounded-lg text-[#FFFFFF] focus:border-[#9E7FFF] focus:outline-none transition-colors"
                      >
                        <option value="ETH">ETH</option>
                        <option value="USDC">USDC</option>
                        <option value="USDT">USDT</option>
                        <option value="DAI">DAI</option>
                      </select>
                    </div>
                  </div>
                </div>

                {/* Summary */}
                <div className="bg-[#171717] rounded-lg p-6 border border-[#2F2F2F]">
                  <h4 className="text-lg font-bold text-[#FFFFFF] mb-4">Summary</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-[#A3A3A3]">Name:</span>
                      <span className="text-[#FFFFFF]">{nftData.name || 'Not set'}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-[#A3A3A3]">Personality:</span>
                      <span className="text-[#FFFFFF]">{nftData.personality || 'Not set'}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-[#A3A3A3]">Abilities:</span>
                      <span className="text-[#FFFFFF]">{nftData.abilities.length} selected</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-[#A3A3A3]">Liquidity:</span>
                      <span className="text-[#FFFFFF]">
                        {nftData.liquidityAmount || '0'} {nftData.liquidityToken}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Navigation Buttons */}
            <div className="flex items-center justify-between mt-8">
              <button
                onClick={() => setStep(Math.max(1, step - 1))}
                disabled={step === 1}
                className="px-6 py-3 bg-[#262626] rounded-lg font-medium text-[#FFFFFF] border border-[#2F2F2F] hover:border-[#9E7FFF] transition-all disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Previous
              </button>

              {step < 4 ? (
                <button
                  onClick={() => setStep(step + 1)}
                  className="px-6 py-3 bg-gradient-to-r from-[#9E7FFF] to-[#38bdf8] rounded-lg font-medium text-[#FFFFFF] hover:scale-105 transition-transform"
                >
                  Next
                </button>
              ) : (
                <button
                  onClick={handleMint}
                  disabled={!nftData.name || !nftData.personality || nftData.abilities.length === 0}
                  className="px-8 py-3 bg-gradient-to-r from-[#9E7FFF] to-[#38bdf8] rounded-lg font-bold text-[#FFFFFF] hover:scale-105 transition-transform disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
                >
                  <Sparkles className="w-5 h-5" />
                  Mint NFT
                </button>
              )}
            </div>
          </motion.div>
        </AnimatePresence>
      </div>
    </section>
  );
}
