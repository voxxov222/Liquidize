import Header from './components/Header';
import Hero from './components/Hero';
import CreateNFT from './components/CreateNFT';
import Portfolio from './components/Portfolio';
import CrossChainBridge from './components/CrossChainBridge';

function App() {
  return (
    <div className="min-h-screen bg-[#0F172A] text-[#FFFFFF]">
      <Header />
      <Hero />
      <CreateNFT />
      <Portfolio />
      <CrossChainBridge />
      
      {/* Footer */}
      <footer className="py-12 px-6 border-t border-[#2F2F2F] bg-[#0F172A]">
        <div className="max-w-7xl mx-auto text-center">
          <p className="text-[#A3A3A3]">
            © 2025 Liquidize. Revolutionizing NFTs with AI and instant liquidity.
          </p>
        </div>
      </footer>
    </div>
  );
}

export default App;
